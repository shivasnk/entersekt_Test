package com.entersekt.test.step_definitions;


import static org.testng.AssertJUnit.assertEquals;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class BlankStepDefs{
public WebDriver driver;
public BlankStepDefs() 
{ 
 
} 
/*@When("^I open seleniumframework website$") 
public void i_open_seleniumframework_website() throws Throwable 
{ // Write code here that turns the phrase above into concrete actions 
driver.get("https://www.entersekt.com/Company-The-team"); 
}
@Then("^I validate title and URL$")
public void i_print_title_and_URL() throws Throwable {
// Write code here that turns the phrase above into concrete actions
assertEquals("Selenium Framework | Selenium, Cucumber, Ruby, Java et al.",driver.getTitle());
assertEquals("http://www.seleniumframework.com/",driver.getCurrentUrl());}
*//*@Given("^I have (\\d+) cukes in my belly$")
public void i_have_cukes_in_my_belly(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
}
ceo name: .//*[@id='features']/div/div/div[2]/div[1]/h2/span/strong/span
.//*[@id='features']/div/div/div[2]/div/h2/span/strong/span
.//*[@id='features']/div/div/div[3]/div/h2/span/strong/span
.//*[@id='features']/div/div/div[4]/div/h2/span/strong/span
.//*[@id='features']/div/div/div[4]/div/h2/span/strong/span
*/

@Given("^open chrome browser$")
public void open_chrome_browser() throws Throwable {
  driver = Hooks.driver; 
}

@When("^I open https://www\\.entersekt\\.com/Company-The-team website$")
public void i_open_https_www_entersekt_com_Company_The_team_website() throws Throwable {
	driver.get("https://www.entersekt.com/Company-The-team"); 
}

@Then("^I validate ceo SCHALK NOLTE$")
public void i_validate_ceo_SCHALK_NOLTE() throws Throwable {
	WebElement ceo = driver.findElement(By.xpath(".//*[@id='features']/div/div/div[2]/div[1]/h2/span/strong/span"));
	
	System.out.println("ceo : "+ceo.getText());
	System.out.println("ceo : "+ceo.getTagName());
	
	
	assertEquals(ceo.getText(), "SCHALK NOLTE");
} 

@Then("^I validate non executive members$")
public void i_validate_non_executive_members() throws Throwable {
	
	//System.out.println(arg0);
	
	//assertTrue(driver.getPageSource().contains("NATHAN MINTAH"));
	
	List<WebElement> list = driver.findElements(By.xpath(".//*[@id='features']/div/div/div[2]/div/h2/span/strong/span"));
	
	assertEquals(list.get(3).getText(), "RAMZI MANSOUR");
	
List<WebElement> list2 = driver.findElements(By.xpath(".//*[@id='features']/div/div/div[3]/div/h2/span/strong/span"));

for (Iterator iterator = list2.iterator(); iterator.hasNext();) {
	WebElement webElement = (WebElement) iterator.next();
	System.out.println("2 : "+webElement.getText());
}
	
	assertEquals(list2.get(2).getText(), "NATHAN MINTAH");
	
List<WebElement> list3 = driver.findElements(By.xpath(".//*[@id='features']/div/div/div[4]/div/h2/span/strong/span"));

for (Iterator iterator = list3.iterator(); iterator.hasNext();) {
	WebElement webElement = (WebElement) iterator.next();
	System.out.println("3 : "+webElement.getText());
}
	
	assertEquals(list3.get(1).getText(), "WILLEM VAN BILJON");
	
List<WebElement> list4 = driver.findElements(By.xpath(".//*[@id='features']/div/div/div[5]/div/h2/span/strong/span"));

for (Iterator iterator = list4.iterator(); iterator.hasNext();) {
	WebElement webElement = (WebElement) iterator.next();
	System.out.println("4 : "+webElement.getText());
}
	assertEquals(list4.get(2).getText(), "ANDREAS VON BLOTTNITZ");	
}

}